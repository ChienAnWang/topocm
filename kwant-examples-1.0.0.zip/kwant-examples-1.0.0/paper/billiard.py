import kwant

def stadium(position):
    x, y = position
    x = max(abs(x) - 70, 0)
    return x**2 + y**2 < 100**2

# Build the scattering region.
sys = kwant.Builder()
mylattice = kwant.lattice.square()
sys[mylattice.shape(stadium, (0, 0))] = 0
sys[mylattice.neighbors()] = -1

# Build and attach a lead.
lead_symmetry = kwant.TranslationalSymmetry([0, -1])
lead = kwant.Builder(lead_symmetry)
lead[(mylattice(x, 0) for x in range(30))] = 0
lead[mylattice.neighbors()] = -1
sys.attach_lead(lead)

sys = sys.finalized()

local_dos = kwant.ldos(sys, energy=-3.8)

import matplotlib.pyplot
kwant.plotter.map(sys, local_dos, num_lead_cells=10)
